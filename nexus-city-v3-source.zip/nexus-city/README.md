# NEXUS CITY — An Autonomous Civilization

**Playable browser-based fictional agent-city simulation.** The vehicles are the citizens: they earn money, find work, travel along roads, charge batteries, establish businesses, rent garages, build social relationships, respond to incidents, commission products, and enter competitions.

**Current status:** expanded playable browser prototype (simulation engine v2). This is **not** a finished AAA title, physically calibrated digital twin, continuously running server game, or a product with real LLM inference. The source is designed to grow toward those goals honestly.

## Start the game (iPad, Galaxy S25 Ultra, desktop)

1. Extract this ZIP into a GitHub repository using your browser, or upload the files to a cloud development workspace such as GitHub Codespaces or StackBlitz.
2. In its browser terminal, run:

   ```bash
   npm install
   npm run dev
   ```

3. Open the forwarded Vite port (default 5173) in Safari, Chrome, or a desktop browser. The game itself needs no paid APIs, accounts or keys.
4. To publish the site, connect the repository to Vercel, Netlify, or Cloudflare Pages. Use **build command** `npm run build` and **output directory** `dist`.
5. For checks after installing dependencies:

   ```bash
   npm run build
   npm test
   ```

A running **hosted static site** loads the simulation on your device; static hosting does not make the game continue when your browser is closed. You will eventually need a continuously running authoritative simulation backend for that.

## How to play

- **City View:** orbit and pinch-zoom the 3D city; tap a vehicle to inspect its identity, finances, battery, planner decisions, personal history, and relationships. Follow it with the camera. Pause/resume or set the clock from 1× to 10×.
- **+1h:** fast-forward one simulated hour, advancing the real agent logic and economy rather than faking the clock. Useful for quickly seeing autonomous decisions and economic consequences.
- **Command Center:** metrics, population, treasury, employment, wealth and recent history from actual world state.
- **Citizens:** inspect agents, grow the population up to 75 via treasury-funded creation grants.
- **Economy:** inspect every retained transfer from the shared ledger. All internal money is stored in integer cents.
- **Businesses:** see operating balances, income, expenses, employment and owner information. Select a citizen first to apply for a job or create a startup.
- **Real Estate:** rent or buy a property using a citizen's wallet. Agents may also autonomously rent or buy as their fortunes permit. Listings require ownership.
- **Traffic:** inspect each path and energy level. Routes are graph-based A* over the fixed compact road network.
- **Emergency Dispatch:** agent battery failures cause incidents. Dispatch a tow; fictional roadside services affect accounts and can restore stranded agents.
- **Industry:** commission a fictional manufactured component. It consumes actual simulated money and production time, but does not produce a real-world item.
- **Competitions:** fund a 900-simulated-second endurance event. Winner is calculated from actual distance and completed jobs, and receives a real in-game treasury transfer.
- **Agent Operations:** see structured decision histories, memories, social interactions, and active event records.
- **City Stories:** view financial rankings and important events derived from simulated history; no fabricated news items.
- **Governor:** modify taxation, public/home charging tariffs, public payroll, rescue policy; seed a citizen grant, trigger a reset, save/export/import, or start fresh. Some actions are sandbox interventions.
- **World Editor:** rezone 36 lots and modify building heights, without breaking the fixed road graph. This is deliberately a restricted functional editor, not arbitrary terrain editing.
- **System & Roadmap:** see connected versus unavailable capabilities and graphics quality.

**Tip:** Select a citizen in City View first, then visit Business, Real Estate, Industry, or Governor to act on that citizen's behalf.

## Economic rules and observability

- 26 seeded citizens, each with **exactly $25,000, 100% battery, no personal property**.
- Fictional seed economy includes municipal, commercial-demand, utility, and business accounts. All internal accounts count toward total money conservation.
- Public full-charge equivalent **$40**; home **$20**. Partial charges are proportionally priced. Home charging requires a garage lease in this prototype.
- Jobs pay real wages from employers. Businesses receive funded customer contract revenue from a seeded demand account. Employees pay configurable municipal income tax.
- Garages support offers, rent payments, transfers, and recurring monthly rent. Buyers cannot spend more cash than they have, and all transactions have a logged payer and payee.
- Businesses can form through capital and permit payments; new jobs update actual employment records.
- Autonomy is a deterministic utility heuristic influenced by individual traits, not a hidden AI model. Some citizen dialogue is template-generated from real social events.
- Unrecoverable stranded citizens may be retired after a recovery window. Their remaining wallet is settled to the treasury, their owned properties return to public ownership, and a replacement identity receives a treasury-funded grant. Previous citizen history is archived.
- Speed citations for high-risk sporty cars require a simulated officer nearby and deduct actual money; this is not real police operation.
- Data logs are bounded in the browser for efficiency. A durable long-term event store would need a server.

## Persistence

World state is saved in **IndexedDB** about every 12 real seconds, on important UI changes, and when the document becomes hidden. Governor includes **Save**, **Export JSON**, **Import JSON**, and **New civilization** actions. Exported JSON is portable between browser installations. Import validates known schema v2 and size; browser-local storage can be cleared by the OS or browser. Old v1 IndexedDB worlds are best-effort migrated, preserving seed, citizen balances, batteries and locations; complex v2 economies are reinitialized.

## Architecture

- `src/simulation/engine.ts`: independently testable deterministic world state, fixed-step tick, decision planners, currency ledger, jobs, agents, incidents, businesses, property, social mechanics, competition, industry and editor rules.
- `src/city/CityScene.tsx`: 3D-only city renderer with buildings, vehicles, lighting, route highlights, touch camera and selection. Does not authoritatively own balances or agent state.
- `src/App.tsx`: responsive UI, live operation panels, speed controls, governor actions, viewport and UI refresh.
- `src/persistence/store.ts`: IndexedDB autosaves, v1→v2 migration, import/export.
- `src/integrations/hardware.ts`: future telemetry and hardware command types; commands **fail closed** today.
- `tests/engine.test.ts`: Vitest economy, routing, autonomy, recovery, property, competition, factory, seed and timing checks.

### Engine time model

One `step(world, 1)` advances exactly one **simulated second**. The app accumulates 3 seconds per real second at 1×; 2× / 5× / 10× multiply this rate. Physics, wallets, policy, travel, contracts and calendar use simulated time only. Browser rendering interpolates positions and refreshes UI separately. Simulation pauses when the tab is hidden or browser is closed.

## What is deliberately unfinished

- Photoreal licensed automotive meshes, accurate BeamNG-type tire and collision physics, sophisticated lights/traffic signals and procedural city expansion.
- Advanced contract auctions, dynamic equilibrium markets, deep long-term relationship memory, lending and bankruptcy resolution, full cadastral or industrial IP systems.
- Full drag-and-drop road editing, road topology changes, physical-scale calibration and arbitrary object placement.
- Full 75-agent performance testing on all target devices, device-specific graphics tuning and offline PWA support.
- A secure optional LLM gateway for dialogue or proposals. **No external LLM is needed or currently configured.**
- Server-authoritative gameplay, multi-device synchronization, authentication and operation while the browser is closed.
- Actual radio controls, localization, cameras, charging hardware, physical fabrication, sensor telemetry and real digital-twin synchronization. Independent safety and emergency-stop hardware are mandatory before any physical control is allowed.

## Build/test verification note

In the environment that produced this source, network DNS for the public npm registry was unavailable. The simulation engine did pass independent TypeScript compilation and direct Node execution tests including 8,000 simulated ticks and conservation of total funds. Source syntax was checked with the installed TypeScript compiler; a separate local type-check with temporary dependency type stubs also passed. **A complete npm dependency install, Vitest invocation, interactive browser graphics check, and Vite production build could not be executed here.** Run `npm install && npm test && npm run build` in your GitHub Codespace before publishing.

## Target physical project

Future physical concept: roughly 1:32 scale, 20 × 20-ft primary city, 40 × 40-ft pole barn, around 1,000 ft of paving, four charging hubs with ten stalls apiece. These are design intentions, not calibrated measurements. Digital Twin and Hardware Control modes must not be represented as online until real telemetry, access control and independent safety systems have been engineered and validated.

---

# NEXUS CITY V3 — Foundation & Autonomy Increment

This archive upgrades **the provided V2 source**, retaining its React interface, R3F city, economic ledger, buildings, business and property systems, citizens, manufacturing, dispatch, competitions, local save store, and hardware-control rejection boundary.

## Changes actually implemented

- **V3 schema and migration**: A valid V2 IndexedDB primary save is backed up under `v2-backup` *before* promotion to V3. Citizens, wallets, accounts, transactions, business relationships, property leases, memories, and simulation time are retained. Valid JSON V2 exports can also be imported.
- **Stricter integrity checks**: Import validation now rejects dangling citizen/employer/business/property/incident references, duplicate business/property IDs, mismatched business-employee lists, and invalid ledger money amounts. Rejected imports leave the running world unchanged.
- **Decision audit**: New deterministic goal utility scoring considers battery, wallet, employment, ambition, sociability and curiosity. Stores planner candidates, scores, inputs, the selected action and its stated expected outcome in each citizen's `plannerHistory`.
- **Fresh Civilization scenario**: The Governor offers a second seeded starting mode. Every citizen starts with $25,000, 100% battery, no property, no personally owned business and no job. The city infrastructure and pre-funded businesses remain available, but hiring is driven by citizen actions.
- **Fast-forward Web Worker**: Governor actions run one simulated hour, day or week in a separate worker with progress reporting. Simulated financial outcomes still come from deterministic one-second `step` calls. The live main-thread scheduler is temporarily suspended while fast-forward is active. This is *not* yet full-time simulation-worker migration.
- **25× speed choice** and V3 regression tests for planner determinism, invalid references, fresh-world conditions, and 75-agent accounting.

## Test report / limitations

- `npm install --offline --no-audit --no-fund`: **FAILED** (`ENOTCACHED`: npm dependencies not preloaded). Consequently full `npm test` and `npm run build` could not be run here; no production browser/device verification is claimed.
- `tsc src/simulation/engine.ts --target es2022 --module commonjs --skipLibCheck --outDir ... --strict`: **PASSED**.
- TypeScript `transpileModule` syntax diagnostics for `App.tsx`, `engine.ts`, `store.ts`, `fastForward.worker.ts`: **0** for each; this is **not** a full type check.
- Direct Node engine check: seeded 75-citizen world passes `validateWorld` both before and after 7,200 simulated seconds, and the initial/final integer-cent `totalMoney` values match. Fresh scenario with 26 citizens passes validation and all citizens initially have no employer.

## Future work not delivered in this increment

Upgraded glTF vehicle models and cinematic rendering; entirely editable, serializable road graph; 75-agent mobile FPS measurements; queueing charging sessions; full long-run power balancing; formal contracts with competitive bidding; persistent indexed economic demand; advanced relationship graph; fully worker-authoritative real-time simulation; server-backed persistence; live LLM gateway; hardware telemetry and safety validation. These are **not** working V3 features yet. The existing 49-node grid remains in place for save compatibility.

## Mobile/cloud instructions

Upload the source into GitHub using iPad Safari or Android Chrome, open a GitHub Codespace and run `npm install && npm test && npm run build && npm run dev`. Open the forwarded Vite preview in the browser. Static deployment is possible after a successful cloud build (for example, via Vercel). Saved IndexedDB data is local to the particular browser and origin; export JSON for a portable backup. The world does not keep simulating while the tab is closed.

**Safety**: Digital Twin and Hardware Control remain unavailable. Simulated actions are not physical commands.
