import {describe,it,expect} from 'vitest';
import {createWorld,evaluateCitizen,step,validateWorld,totalMoney,addCitizen} from '../src/simulation/engine';
describe('V3 autonomy & validation',()=>{
 it('fresh scenario has no employed citizens or private businesses',()=>{const w=createWorld(94,26,'fresh');expect(w.citizens.every(c=>c.employer===null&&c.wallet===2500000&&c.battery===100)).toBe(true);expect(w.businesses.every(b=>b.ownerId===null)).toBe(true);expect(validateWorld(w)).toBe(true);});
 it('planner records comparative scores with deterministic selection',()=>{const w=createWorld();const a=evaluateCitizen(w,w.citizens[0]);const b=evaluateCitizen(w,w.citizens[0]);expect(a).toEqual(b);expect(a.candidates.length).toBeGreaterThan(3);});
 it('rejects dangling employer and property references',()=>{const w=createWorld();w.citizens[0].employer='B-NONEXISTENT';expect(validateWorld(w)).toBe(false);});
 it('conserves money while evolving a 75-citizen city',()=>{const w=createWorld(89,75);const total=totalMoney(w);step(w,7200);expect(totalMoney(w)).toBe(total);expect(w.citizens.length).toBe(75);expect(validateWorld(w)).toBe(true);});
 it('accepts growing the population while accounting for grants',()=>{const w=createWorld();const total=totalMoney(w);expect(addCitizen(w)).toBe(true);expect(totalMoney(w)).toBe(total);});
});
