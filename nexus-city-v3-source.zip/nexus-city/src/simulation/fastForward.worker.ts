import {step,type World} from './engine';

type Request={world:World;seconds:number};
self.onmessage=(message:MessageEvent<Request>)=>{
 const {world,seconds}=message.data;
 if(!Number.isSafeInteger(seconds)||seconds<1||seconds>604800){self.postMessage({type:'error',error:'Invalid fast-forward duration'});return;}
 const paused=world.paused;world.paused=false;
 let processed=0;
 const chunk=()=>{
  try{
   const count=Math.min(900,seconds-processed);
   step(world,count);processed+=count;
   if(processed<seconds){self.postMessage({type:'progress',processed,total:seconds});setTimeout(chunk,0);}
   else {world.paused=paused;self.postMessage({type:'complete',world});}
  }catch(error){self.postMessage({type:'error',error:error instanceof Error?error.message:'Simulation failure'});}
 };
 chunk();
};
