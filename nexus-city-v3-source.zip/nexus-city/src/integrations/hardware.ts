/** Future integration boundary. Simulation mode cannot issue physical commands. */
export type ExecutionMode='simulation'|'digital-twin'|'hardware-control';
export type VehicleTelemetry={deviceId:string;timestamp:number;position:{x:number;z:number};batteryPercent:number;signalQuality:number};
export type HardwareCommand={deviceId:string;action:'stop'|'drive'|'dock'|'lights';arguments:Record<string,number|string|boolean>};
export type HardwareResponse={accepted:boolean;executed:boolean;reason:string};
/** Must remain fail-closed until a separately validated gateway is deployed. */
export const currentMode:ExecutionMode='simulation';
export async function submitHardwareCommand(_command:HardwareCommand):Promise<HardwareResponse>{return {accepted:false,executed:false,reason:'Physical command rejected: hardware gateway, identity verification, independent emergency stop and safety controller are not installed.'};}
export async function connectDigitalTwin():Promise<never>{throw new Error('Digital Twin mode unavailable: no calibrated geometry or telemetry gateway.');}
